package edu.erp.entidades.errores;

public class ErrorServicio extends Exception{
    
    public ErrorServicio(String msn){
        super(msn);
    }
    
}
