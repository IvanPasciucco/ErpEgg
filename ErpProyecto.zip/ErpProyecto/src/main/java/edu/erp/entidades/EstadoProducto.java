package edu.erp.entidades;

public class EstadoProducto {

private Object aceptado;
private Object pendiente;
private Object rechazado;

    
}
